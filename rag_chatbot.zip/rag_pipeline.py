# rag_pipeline.py

from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.document_loaders import CSVLoader
from langchain.chains import RetrievalQA
from langchain.chat_models import ChatOpenAI
import os

def load_data(csv_path):
    loader = CSVLoader(file_path=csv_path)
    documents = loader.load()
    return documents

def create_vectorstore(documents):
    text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    texts = text_splitter.split_documents(documents)
    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_documents(texts, embeddings)
    return vectorstore

def build_rag_pipeline(csv_path):
    documents = load_data(csv_path)
    vectorstore = create_vectorstore(documents)
    retriever = vectorstore.as_retriever()
    llm = ChatOpenAI(model_name="gpt-3.5-turbo")
    qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
    return qa_chain
