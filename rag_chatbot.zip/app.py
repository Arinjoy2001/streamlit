# app.py

import streamlit as st
from rag_pipeline import build_rag_pipeline
import os

st.set_page_config(page_title="RAG Chatbot", layout="centered")
st.title("🧠 RAG-based Chatbot")

CSV_PATH = "data/your_dataset.csv"

os.environ["OPENAI_API_KEY"] = st.secrets.get("OPENAI_API_KEY", "")

qa_chain = build_rag_pipeline(CSV_PATH)

query = st.text_input("Ask a question based on your dataset:")
if query:
    with st.spinner("Thinking..."):
        answer = qa_chain.run(query)
    st.success(answer)
