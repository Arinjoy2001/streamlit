# 🧠 RAG-based Chatbot using LangChain

This project is a Retrieval-Augmented Generation (RAG) Chatbot that uses external data sources to answer questions contextually. Built using Python, LangChain, and Streamlit.

## 📌 Features

- Load data from a CSV file as a knowledge base
- LangChain pipeline with OpenAI and FAISS
- Ask questions and receive accurate answers using RAG
- Streamlit interface (Bonus points!)
- Sample response log included

---

## 📁 Project Structure

```
rag_chatbot/
│
├── data/
│   └── your_dataset.csv             # Your custom dataset
├── app.py                           # Streamlit frontend
├── rag_pipeline.py                  # LangChain RAG logic
├── sample_responses.xlsx            # Example Q&A from the chatbot
├── requirements.txt                 # Dependencies
└── README.md                        # Project documentation
```

---

## 🚀 Setup Instructions

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/rag-chatbot.git
cd rag_chatbot
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Set OpenAI API Key
Add your key to a `.streamlit/secrets.toml` file (for Streamlit deployment) or export it:
```bash
export OPENAI_API_KEY="your-api-key"
```

### 4. Run the App
```bash
streamlit run app.py
```

---

## 📄 Sample Q&A File

See `sample_responses.xlsx` for sample chatbot questions and answers.

---

## 📤 Submission Instructions

1. Push all files to your GitHub repository.
2. Send the GitHub repository link and optionally your Streamlit link to:

   - 📧 **satvik@buildfastwithai.com**
   - 📧 **shubham@buildfastwithai.com**

---

## 📚 Citations

- [LangChain Docs](https://docs.langchain.com/)
- [Streamlit](https://streamlit.io/)
- [OpenAI API](https://platform.openai.com/)

---

## ✅ Contributors

- 👨‍💻 Your Name (AI Intern Applicant)
